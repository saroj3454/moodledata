<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_mdl_course_enroll';
$plugin->version   = 2019052000;
$plugin->release = '2';
$plugin->maturity = MATURITY_STABLE;
$plugin->requires  = 2019051100; 

